#!/bin/bash
echo Start master