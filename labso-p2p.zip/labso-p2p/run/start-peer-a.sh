#!/bin/bash
echo Start peer A