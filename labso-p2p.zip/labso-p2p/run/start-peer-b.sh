#!/bin/bash
echo Start peer B