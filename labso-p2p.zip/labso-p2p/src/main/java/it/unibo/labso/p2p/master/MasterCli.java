package it.unibo.labso.p2p.master;
public class MasterCli implements Runnable {
    @Override public void run() { System.out.println("master> listdata | quit"); }
}
