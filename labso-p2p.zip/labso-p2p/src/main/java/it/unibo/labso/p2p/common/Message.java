package it.unibo.labso.p2p.common;
public record Message(String cmd, String json) {}